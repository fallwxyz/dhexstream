<?php 
    require_once "function.php";
    // require_once "database/connection.php";
    require_once "tools.php";
    DhexConfig::load();
    loadDhex(dirname(__DIR__) . '/.dhex');

?>